Idle frames: 6-45
Walking frames: 70-110
Running frames: 115-128
Attack 1 wind-up: 132 - 137
Attack 1 swing: 138 - 147
Attack 2 wind-up: 148 - 153
Attack 2 swing: 154 - 160
Attack 3 wind-up: 161 - 169
Attack 3 swing: 170 - 176
Special Attack: 188 - 207
Dodge Roll: 222 - 243
Recoil frames: 247 - 262
Death frames: 274 - 300